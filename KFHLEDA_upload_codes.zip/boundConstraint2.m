function vi = boundConstraint2 (vi, pop, lu)

% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
% 如果违反边界约束，则将值设置为中间值前一个值和绑定值的百分比


[NP, ~] = size(pop);  % the population size and the problem's dimension

%% check the lower bound
xl = repmat(lu(1, :), NP, 1);
% load('2017-1-13.mat');

pos = vi < xl;
vi(pos) = (pop(pos) + xl(pos)) / 2;% 按列操作

%% check the upper bound
xu = repmat(lu(2, :), NP, 1);
pos = vi > xu;
vi(pos) = (pop(pos) + xu(pos)) / 2;