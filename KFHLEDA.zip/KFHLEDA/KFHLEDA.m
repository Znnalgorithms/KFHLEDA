
clc;
clear all;

format long;
format compact;

val_2_reach = 10^(-200);

fhd=@cec17_func;

runs = 30;
RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEsFactor);

for problem_size = 10
    max_nfes = 10000 * problem_size;
    rand('seed', sum(100 * clock));
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
    fprintf('Running algorithm\n')
    
    for func = 9
        optimum = func * 100.0;
        
        outcome = [];
        
%         fprintf('\n-------------------------------------------------------\n')

        
        allerrorvals = zeros(progress, runs);
        for run_id = 1 : runs
            a = [];
            b = [];
            run_funcvals = [];
            nfes = 0;
           
            PS_max = 3000;
            PS_min = 0.5 * (problem_size^2 + problem_size);
            PS = PS_max;
            min_PS = PS_min;
            max_PS = PS_max;
           
            tao = 0.35;
            nta_max = 5;
            NN = floor(PS * tao);
            
            popold = repmat(lu(1, :), PS, 1) + rand(PS, problem_size) .* (repmat(lu(2, :) - lu(1, :), PS, 1));
            pop = popold;
            fitness = feval(fhd,pop',func);
            fitness = fitness';
            
            bsf_fit_var = 1e+30;
            bsf_index = 0;
            bsf_solution = zeros(1, problem_size);
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            for i = 1 : PS
                nfes = nfes + 1;
                if (fitness(i) < bsf_fit_var && isreal(pop(i, :)) && sum(isnan(pop(i, :)))==0 && min(pop(i, :))>=-100 && max(pop(i, :))<=100)
                    bsf_fit_var = fitness(i);
                    bsf_solution = pop(i, :);
                    bsf_index = i;
                end
                
                if nfes > max_nfes
                    break;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            
            run_funcvals = [run_funcvals;ones(PS,1)*bsf_fit_var];
            
            archive.l = 20;
            archive.NP = archive.l * NN; 
            archive.pop = zeros(0, problem_size); 
            archive.funvalues = zeros(0, 1); 
            
            [FitnessValue, index]=sort(fitness);
            i = 1 : NN;
            Sup_Pop(i,:)=pop(index(i),:);
            
            pop1(i,:)=Sup_Pop(i,:);
            fitness_sup=FitnessValue(1:NN,:);

            [~, indexbestX] = min(FitnessValue);
            bsf_solution = pop(indexbestX, :);
            
           AA=[archive.pop; Sup_Pop];     
           mut1 = mean(pop1(i,:));
           
           ct = (AA - repmat(mut1,size(AA,1),1))' * (AA - repmat(mut1,size(AA,1),1));
           ct = ct/(size( AA, 1));
           ct = (ct + ct.') / 2;
           
           pop2=mvnrnd(mut1,ct,round((1-tao)*PS));             
           

           pop1_new=[pop1; pop2];
           pop1_new=boundConstraint2(pop1_new,pop,lu);
           fitness1=feval(fhd,pop1_new',func);
           fitness1=fitness1';

           for j=1:size(pop1_new,1)             
               if fitness1(j)<bsf_fit_var                   
                   bsf_fit_var=fitness1(j);
                   bsf_solution=pop1_new(j,:);
                   bsf_index=j;
               end
            end

            if nfes > max_nfes             
                break;
            end
            pop = pop1_new;
            p=100;
            PS =p;
            max_PS = p;       
            A(i,:) = [bsf_solution - pop2(i,:)]; 
            t = 0;
            g = 0;
            while nfes < max_nfes
                ct = 0;
                nta = 0;
                Sup_Pop = [];
                Inf_Pop = [];
                mu_tm1 = [];
                NN = floor(PS * tao);
                [FitnessValue,index]=sort(fitness);
                i=1:NN;
                          
                iNumber = numel(i);
                randomNumber = rand(1,iNumber);
                
                pop1(i,:) = eye([iNumber, problem_size]) * bsf_solution'+diag(randomNumber)*A(i,:);                   
                
                Sup_Pop(i,:) = pop(index(i),:);
                fitness_sup = FitnessValue(1:NN,:);
                
               fitness2 = feval(fhd,pop',func);
               fitness2 = fitness2';
               [FitnessValue2, index]=sort(fitness2);                
                              
               [~, indexbestX] = min(fitness2);
                
               bsf_solution_fit = min(fitness2);
               wst_solution_fit = max(fitness2);                   
               

               [ev,ed]=eig(ct);
               
               if ed < 0 & abs(bsf_solution_fit-wst_solution_fit) < 10^-4 
                   if tao<=0.90
                        tao=tao+0.10;
                   elseif tao>0.90
                        tao=tao-0.90;
                   end

               else
                   d=sum(A(i,:));
                   e=sum(A(i,:)*sum(bsf_solution_fit - fitness2)/NN);
                   f=d/e;
                   
                   pop2_new = pop(i, :) + f*(bsf_solution -fitness2(i, :)).*A(i,:);                         
                   
                   fit = feval(fhd,pop2_new',func);                   
                   fit = fit';
                   for j=1:size(pop2_new,1)                    
                        if fit(j)<bsf_fit_var
                            bsf_fit_var=fit(j);
                            bsf_solution=pop2_new(j,:);
                            bsf_index=j;
                        end
                        if nfes>max_nfes
                            break;
                        end
                   end        
                   
                   mut2 = mean(AA(i,:)+f .* (bsf_fit_var - fit(i)) .*A(i,:));                    
                    for i = 1:size( Sup_Pop, 1)
                        a(i,:) = (sum(FitnessValue(1 : NN,1)) - FitnessValue(i)).*  Sup_Pop(i,:);
                        b(i,:) = sum(FitnessValue(1 : NN,1)) - FitnessValue(i);
                    end

                    a = sum(a,1);
                    b = sum(b,1);

                    mut1 = a/b;
                    mu_tm1 = mean(pop,1); 
                    deltat = mut1 - mu_tm1;
                    mut2 = mut1;

                    AA = [archive.pop;Sup_Pop];
                    ct = (AA - repmat(mut2,size(AA,1),1))' * (AA - repmat(mut2,size(AA,1),1));
                    ct = ct/(size( AA, 1));
                    ct = (ct + ct.') / 2;
                    
                    if g < archive.l
                        archive.pop = [archive.pop;Sup_Pop];
                        archive.funvalues = [archive.funvalues; fitness_sup];
                    else
                        archive.pop(1:NN,:) = Sup_Pop;
                        archive.funvalues(1:NN,:) = fitness_sup;
                        archive.pop = [archive.pop(NN + 1:end,:);archive.pop(1:NN,:)];
                        archive.funvalues = [archive.funvalues(NN + 1:end,:);archive.funvalues(1:NN,:)];
                    end


                    pop_EDA = mvnrnd(mut2,ct,PS-1);
                    pop_EDA = [pop_EDA;bsf_solution];
                    %pop_EDA = boundConstraint2(pop_EDA,pop,lu);
                    
                    pop_new = pop_EDA;
                    fitness3 = feval(fhd,pop_new',func);
                    fitness3 = fitness3';
                    %%%%%%%%%%%%%%%%%%%%%%%% for out
                    for j = 1 : size(pop_new,1)
                        nfes = nfes + 1;
                        if fitness3(j) < bsf_fit_var
                            bsf_fit_var = fitness3(j);
                            bsf_solution = pop_new(j,:);
                            bsf_index = j;
                            %                         g = 1;
                        end
                        if nfes > max_nfes
                            break;
                        end
                    end
                   
                    run_funcvals = [run_funcvals;ones(PS,1)*bsf_fit_var];
                    
                    fitness = fitness3;
                    pop_new = pop_EDA;
                    pop = pop_new;
                    
                    plan_pop_size = round((((min_PS - max_PS) / max_nfes) * nfes) + max_PS);
                    %                 NFEr  = nfes/max_nfes;
                    %                 plan_pop_size = round((((min_pop_size - max_pop_size) / max_nfes) * power(NFEr,1 - NFEr)) + max_pop_size);

                    if PS > plan_pop_size
                        reduction_ind_num = PS - plan_pop_size;
                        if PS - reduction_ind_num <  min_PS;
                            reduction_ind_num = PS - min_PS;
                        end

                        PS = PS - reduction_ind_num;
                        %SEL = round(ps*pop_size);
                        %fitness_old=fitness;
                        for r = 1 : reduction_ind_num
                            [valBest indBest] = sort(fitness, 'ascend');
                            worst_ind = indBest(end);
                            popold(worst_ind,:) = [];
                            pop(worst_ind,:) = [];
                            fitness(worst_ind,:) = [];
                        end
                    end
                    
                    pop_new2 = [pop_EDA; bsf_solution];
                 
                    A(i,:) = [bsf_solution - pop_new2(i,:)];
                    
                    d=sum(A(i,:));
                    e=sum(A(i,:)*sum(bsf_solution_fit - fitness2)/NN);
                    f=d/e;
                                                                   
                   fit = feval(fhd,pop_new2',func);                    
                   fit = fit';
                   for j=1:size(pop_new2,1)                    
                        if fit(j)<bsf_fit_var
                            bsf_fit_var=fit(j);
                            bsf_solution=pop_new2(j,:);
                            bsf_index=j;
                        end
                        if nfes>max_nfes
                            break;
                        end
                   end  

                   pop2_new = pop(i, :) + f*(bsf_solution -fit(i, :)).*A(i,:);        
     
                end
              
                g = g + 1;
                t = t + 1;
            end 
            
            bsf_error_val = abs(bsf_fit_var - optimum);
            
            if(sum(isnan(bsf_solution))>0)
                fprintf('%d th run, NaN\n', run_id)
            end
            fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
            outcome = [outcome bsf_error_val];
            

            errorVals= [];
            for w = 1 : progress
                bestold = run_funcvals(RecordFEsFactor(w) * max_nfes) - optimum;
                if abs(bestold)>1e-200
                    errorVals(w)= abs(bestold);
                else
                    bestold=0;
                    errorVals(w)= bestold;
                end
            end
            allerrorvals(:, run_id) = errorVals;
        end % end 1 run
        fprintf('\n')
        fprintf('mean = %1.2e, std = %1.2e\n',  mean(outcome), std(outcome))
        
        
                file_name=sprintf('Results\\KFHLEDA_CEC2017_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
                save(file_name,'outcome', 'allerrorvals');
        
        
                file_name=sprintf('Results\\KFHLEDA_%s_%s.txt',int2str(func),int2str(problem_size));
                save(file_name, 'allerrorvals', '-ascii');
    end % end 1 func
end