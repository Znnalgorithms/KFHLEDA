function m = is_mnet(model)

m = isfield(model, 'markov_net');
