Decision/regression tree CPD
Author: Yimin Zhang yimin.zhang@intel.com
21 Jan 2002


See also Paul Bradley's Multisurface Method-Tree matlab code
 http://www.cs.wisc.edu/~paulb/msmt/
http://www.cs.wisc.edu/~olvi/uwmp/msmt.html
