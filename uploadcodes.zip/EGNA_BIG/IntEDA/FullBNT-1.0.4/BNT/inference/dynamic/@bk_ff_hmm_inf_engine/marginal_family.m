function m = marginal_family(engine, i, t)
% MARGINAL_FAMILY Compute the marginal on the specified family (bk_ff_hmm)
% marginal = marginal_family(engine, i, t)

error('bk_ff_hmm doesn''t support marginal_family');
